﻿using System;

class Book
{
    private string title;
    private string author;
    private int year;
    private double price;

    public void SetData(string title, string author, int year, double price)
    {
        this.title = title;
        this.author = author;
        this.year = year;
        this.price = price;
    }

    public override string ToString()
    {
        return $"Книга: \"{title}\" | Автор: {author} | Рік: {year} | Ціна: {price} грн";
    }

    public override bool Equals(object obj)
    {
        if (obj == null || GetType() != obj.GetType())
        {
            return false;
        }

        Book other = (Book)obj;

        return title == other.title &&
               author == other.author &&
               year == other.year &&
               price == other.price;
    }

    public override int GetHashCode()
    {
        return HashCode.Combine(title, author, year, price);
    }
}