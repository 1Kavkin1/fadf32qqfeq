﻿using System;
using System.Text;

class Program
{
    static void Main()
    {
        Console.OutputEncoding = Encoding.UTF8;
        Console.InputEncoding = Encoding.UTF8;

        Console.WriteLine("=== Введення даних для першої книги ===");
        Console.Write("Введіть назву: ");
        string title1 = Console.ReadLine();

        Console.Write("Введіть автора: ");
        string author1 = Console.ReadLine();

        Console.Write("Введіть рік видання: ");
        int year1 = int.Parse(Console.ReadLine());

        Console.Write("Введіть ціну: ");
        double price1 = double.Parse(Console.ReadLine());

        Book book1 = new Book();
        book1.SetData(title1, author1, year1, price1);

        Console.WriteLine("\n=== Введення даних для другої книги ===");
        Console.Write("Введіть назву: ");
        string title2 = Console.ReadLine();

        Console.Write("Введіть автора: ");
        string author2 = Console.ReadLine();

        Console.Write("Введіть рік видання: ");
        int year2 = int.Parse(Console.ReadLine());

        Console.Write("Введіть ціну: ");
        double price2 = double.Parse(Console.ReadLine());

        Book book2 = new Book();
        book2.SetData(title2, author2, year2, price2);

        Console.WriteLine("\n=== Результати ===");

        Console.WriteLine("Книга 1: " + book1.ToString());
        Console.WriteLine("Книга 2: " + book2.ToString());

        bool isEqual = book1.Equals(book2);
        Console.WriteLine($"\nЧи однакові книги (Equals)? {isEqual}");

        Console.WriteLine($"Хеш-код Книги 1: {book1.GetHashCode()}");
        Console.WriteLine($"Хеш-код Книги 2: {book2.GetHashCode()}");
    }
}